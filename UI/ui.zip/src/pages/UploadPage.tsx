// frontend/src/pages/UploadPage.tsx
export default function UploadPage() {
  return (
    <div className="text-center py-16">
      <h1 className="text-2xl font-bold text-gray-900 mb-2">Загрузка документов</h1>
      <p className="text-gray-500">
        TODO День 2: DropZone + загрузка файлов + кнопка "Запустить анализ"
      </p>
    </div>
  );
}