// frontend/src/pages/ComparePage.tsx
import { useParams } from "react-router-dom";

export default function ComparePage() {
  const { id } = useParams<{ id: string }>();
  return (
    <div className="text-center py-16">
      <h1 className="text-2xl font-bold text-gray-900 mb-2">Результаты сравнения</h1>
      <p className="text-gray-500">
        ID сравнения: <code className="bg-gray-100 px-2 py-1 rounded">{id}</code>
      </p>
      <p className="text-gray-400 mt-2 text-sm">
        TODO День 2: DiffViewer + ProgressStepper
      </p>
    </div>
  );
}