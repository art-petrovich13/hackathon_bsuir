// frontend/src/hooks/useComparison.ts
// TODO День 2-3: useQuery для GET /api/compare/:id + фильтрация
export {};