// frontend/src/hooks/useUpload.ts
// TODO День 2: реализовать useMutation для загрузки файлов
export {};