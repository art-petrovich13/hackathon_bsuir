# backend/app/api/compare.py
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.schemas import ComparisonCreateSchema, ComparisonResponseSchema

router = APIRouter(prefix="/api", tags=["Compare"])


@router.post("/compare", status_code=202, summary="Создать задачу сравнения")
async def create_comparison(
    payload: ComparisonCreateSchema,
    db: AsyncSession = Depends(get_db),
):
    """
    Принимает два doc_id, создаёт Comparison и запускает Celery таск.
    **TODO День 2:** реализовать.
    """
    raise HTTPException(status_code=501, detail="Будет реализовано в День 2")


@router.get("/compare/{comparison_id}", response_model=ComparisonResponseSchema,
            summary="Получить результат сравнения")
async def get_comparison_result(
    comparison_id: str,
    db: AsyncSession = Depends(get_db),
):
    """**TODO День 2:** реализовать."""
    raise HTTPException(status_code=501, detail="Будет реализовано в День 2")


@router.get("/compare/{comparison_id}/prosecutor",
            summary="Данные модуля ПРОКУРОР")
async def get_prosecutor_data(
    comparison_id: str,
    db: AsyncSession = Depends(get_db),
):
    """**TODO День 5:** реализовать после ProsecutorAnalyzer."""
    raise HTTPException(status_code=501, detail="Будет реализовано в День 5")