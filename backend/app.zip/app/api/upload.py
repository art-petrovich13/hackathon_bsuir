# backend/app/api/upload.py
from fastapi import APIRouter, UploadFile, File, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.schemas import DocumentSchema

router = APIRouter(prefix="/api", tags=["Upload"])


@router.post("/upload", response_model=DocumentSchema, status_code=201,
             summary="Загрузить документ (.docx или .pdf)")
async def upload_document(
    file: UploadFile = File(...),
    db: AsyncSession = Depends(get_db),
):
    """
    Принимает .docx или .pdf файл.
    Возвращает DocumentSchema с id — используй его в POST /api/compare.
    
    **TODO День 2:** реализовать парсинг и сохранение в БД.
    """
    # Валидация расширения файла
    if file.filename:
        ext = file.filename.rsplit(".", 1)[-1].lower()
        if ext not in ("docx", "pdf"):
            raise HTTPException(
                status_code=400,
                detail=f"Неподдерживаемое расширение .{ext}. Разрешены: .docx, .pdf",
            )

    raise HTTPException(status_code=501, detail="Будет реализовано в День 2")