# backend/app/tasks/analysis.py
from app.tasks.celery_app import celery_app


@celery_app.task(bind=True, name="analyze_comparison",
                 max_retries=3, soft_time_limit=300, time_limit=360)
def analyze_comparison(self, comparison_id: str):
    """
    Главный таск анализа. Этапы реализуются по дням:
    День 2: PARSING + DIFFING
    День 3: AI ANALYZING (Gemini)
    День 5: PROSECUTOR
    """
    self.update_state(
        state="STARTED",
        meta={"status": "PENDING", "comparison_id": comparison_id},
    )
    # TODO: реализация в День 2
    return {"status": "not_implemented_yet", "comparison_id": comparison_id}